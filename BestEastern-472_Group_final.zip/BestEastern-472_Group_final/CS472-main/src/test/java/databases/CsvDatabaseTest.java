package databases;

public class CsvDatabaseTest {
    //No idea how to make it throw errors.... haha....
}
