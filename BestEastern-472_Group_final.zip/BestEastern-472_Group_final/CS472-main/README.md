# Best Eastern
```
./mvnw clean package cargo:run
```

Once the runtime starts, you can access the project at <br>http://localhost:8080/best-eastern/pages<br>OR go to<br>https://best-eastern.enmucs.com

