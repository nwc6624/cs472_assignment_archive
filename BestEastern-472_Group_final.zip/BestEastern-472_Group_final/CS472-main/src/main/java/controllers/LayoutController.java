package controllers;

import databases.LayoutDatabase;

public class LayoutController {
    private LayoutDatabase layout;

    public LayoutController(LayoutDatabase layout) {
        this.layout = layout;
    }

    public int getRoomNumber(int floor, int row, int col) {
        return layout.getRoomNumber(floor, row, col);
    }

    public void setRoomNumber(int floor, int row, int col, int roomNumber) {
        layout.setRoomNumber(floor, row, col, roomNumber);
    }

    public void horizontalResize(int newRows) {
        int floors = layout.getRoomLayout().length;
        int rows = layout.getRoomLayout()[0].length;
        int cols = layout.getRoomLayout()[0][0].length;
        int[][][] newLayout = new int[floors][rows + newRows][cols];
        for (int floor = 0; floor < floors; floor++) {
            for (int row = 0; row < rows; row++) {
                System.arraycopy(layout.getRoomLayout()[floor][row], 0, newLayout[floor][row], 0, cols);
            }
        }
        layout.setRoomLayout(newLayout);
    }

    public void widthResize(int newCols) {
        int floors = layout.getRoomLayout().length;
        int rows = layout.getRoomLayout()[0].length;
        int cols = layout.getRoomLayout()[0][0].length;
        int[][][] newLayout = new int[floors][rows][cols + newCols];
        for (int floor = 0; floor < floors; floor++) {
            for (int row = 0; row < rows; row++) {
                System.arraycopy(layout.getRoomLayout()[floor][row], 0, newLayout[floor][row], 0, cols);
            }
        }
        layout.setRoomLayout(newLayout);
    }

    public void verticalResize(int newFloors) {
        int floors = layout.getRoomLayout().length;
        int rows = layout.getRoomLayout()[0].length;
        int cols = layout.getRoomLayout()[0][0].length;
        int[][][] newLayout = new int[floors + newFloors][rows][cols];
        for (int floor = 0; floor < floors; floor++) {
            for (int row = 0; row < rows; row++) {
                System.arraycopy(layout.getRoomLayout()[floor][row], 0, newLayout[floor][row], 0, cols);
            }
        }
        layout.setRoomLayout(newLayout);
    }

    public void shiftFloor(int floorIndex, int rows, int cols) {
        int[][][] roomLayout = layout.getRoomLayout();
        int[][] floorToShift = roomLayout[floorIndex];
        if (isValidForShift(floorToShift, rows, cols)) {
            // Shift the floor in given directions
            int[][] shiftedFloor = new int[rows][cols];
            for (int row = 0; row < rows; row++) {
                for (int col = 0; col < cols; col++) {
                    shiftedFloor[row][col] = floorToShift[row][col];
                }
            }
            roomLayout[floorIndex] = shiftedFloor;
            layout.setRoomLayout(roomLayout);
        }
    }

    private boolean isValidForShift(int[][] floor, int rows, int cols) {
        for (int row = 0; row < rows; row++) {
            for (int col = 0; col < cols; col++) {
                if (floor[row][col] != 0) {
                    // Cannot shift if there are non-zero values because I did not want to add logic to move extra rooms to new places
                    return false;
                }
            }
        }
        return true;
    }
}
