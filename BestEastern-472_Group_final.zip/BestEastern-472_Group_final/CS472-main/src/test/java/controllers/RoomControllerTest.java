package controllers;

public class RoomControllerTest {
}
