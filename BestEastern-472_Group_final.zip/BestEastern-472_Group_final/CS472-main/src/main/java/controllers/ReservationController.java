package controllers;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import databases.ReservationDatabase;
import objects.Reservation;

public class ReservationController {
    private ReservationDatabase reservationDatabase;

    public ReservationController(ReservationDatabase reservationDatabase) {
        this.reservationDatabase = reservationDatabase;
    }

    public void addReservation(Reservation reservation) {
        reservationDatabase.addReservation(reservation);
    }

    public List<Reservation> getAllReservations() {
        return reservationDatabase.getReservations();
    }

    public void removeReservation(int reservationId){
        reservationDatabase.removeReservation(reservationId);
    }

    public Reservation getReservation(int reservationId){
        return reservationDatabase.getReservation(reservationId);
    }

    public boolean checkReservationAvailable(int roomNumber, String start, String end) {
        for (Reservation reservation : reservationDatabase.getReservations()) {
            if (reservation.getRoomNumber() == roomNumber) {
                String reservationStart = reservation.getStartDate();
                String reservationEnd = reservation.getEndDate();
                return isOverlap(start, end, reservationStart, reservationEnd);
            }
        }
        return true; // Room available
    }

    private boolean isOverlap(String start1, String end1, String start2, String end2) {
        LocalDate startTime1 = LocalDate.parse(start1);
        LocalDate endTime1 = LocalDate.parse(end1);
        LocalDate startTime2 = LocalDate.parse(start2);
        LocalDate endTime2 = LocalDate.parse(end2);
        return !((startTime1.isAfter(endTime2) || startTime1.equals(endTime2)) || (endTime1.isBefore(startTime2) || endTime1.equals(startTime2)));
    }

    public List<Reservation> getCustomerReservations(int customerId) {
        List<Reservation> customerReservations = new ArrayList<>();
        for (Reservation reservation : customerReservations) {
            if (reservation.getCustomerId() == customerId) {
                customerReservations.add(reservation);
            }
        }
        return customerReservations;
    }

    public List<Reservation> getRoomReservations(int roomNumber) {
        List<Reservation> roomReservations = new ArrayList<>();
        for (Reservation reservation : roomReservations) {
            if (reservation.getRoomNumber() == roomNumber) {
                roomReservations.add(reservation);
            }
        }
        return roomReservations;
    }
}